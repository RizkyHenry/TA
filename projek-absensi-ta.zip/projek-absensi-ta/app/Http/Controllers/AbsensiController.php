<?php

namespace App\Http\Controllers;

use App\Models\Absensi;
use App\Models\Jabatan;
use App\Models\Detail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

class AbsensiController extends Controller
{
    // Menampilkan daftar absensi
    public function index()
    {
        $user = Auth::user(); // Dapatkan user yang sedang login

        // Cek apakah user terautentikasi
        if (!$user) {
            return redirect()->route('login')->with('error', 'Anda harus login terlebih dahulu.');
        }

        // Ambil absensi berdasarkan jabatan user
        $absensi = Absensi::where('id_jabatan', $user->id_jabatan)->with('detail')->get();

        // Temukan jabatan
        $jabatan = Jabatan::find($user->id_jabatan);
        if (!$jabatan) {
            return redirect()->back()->with('error', 'Jabatan tidak ditemukan.');
        }

        // Kembalikan tampilan dengan data yang diambil
        return view('user.absenkaryawan', compact('absensi', 'jabatan'));
    }

    // Menyimpan data absensi baru
    public function store(Request $request)
    {
        // Validasi data yang diterima
        $request->validate([
            'id_jabatan' => 'required|exists:jabatans,id_jabatan',
            'kehadiran_absen' => 'required|in:sakit,izin,hadir,alpa',
            'tanggal_absen' => 'required|date',
            'foto_selfie' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        // Menyimpan absensi
        $absensi = Absensi::create([
            'id_jabatan' => $request->id_jabatan,
            'kehadiran_absen' => $request->kehadiran_absen,
            'tanggal_absen' => $request->tanggal_absen,
        ]);

        // Menyimpan foto_selfie ke direktori publik
        $foto_selfiePath = $request->file('foto_selfie')->store('details', 'public');

        // Menyimpan detail dengan foto_selfie yang di-upload
        Detail::create([
            'id_absensi' => $absensi->id_absensi,
            'foto_selfie' => $foto_selfiePath, 
            'id_jabatan' => $request->id_jabatan, 
        ]);

        return redirect()->back()->with('success', 'Absensi berhasil ditambahkan!');
    }

    // Menampilkan form untuk absensi
    public function showAbsensiForm()
    {
        $jabatanList = Jabatan::all(); // Ambil semua jabatan
        return view('absensi.form', compact('jabatanList')); // Kirim ke view
    }

    // Menampilkan detail absensi
    public function show($id)
    {
        $absensi = Absensi::with('detail', 'jabatan', 'user')->findOrFail($id);
        return view('absensi.show', compact('absensi'));
    }

    // Mengupdate data absensi
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'id_jabatan' => 'required|exists:jabatans,id_jabatan',
            'kehadiran_absen' => 'required|in:sakit,izin,hadir,alpa',
            'tanggal_absen' => 'required|date',
            'id_detail' => 'required|exists:details,id_detail', // Validasi id_detail
        ]);

        $absensi = Absensi::findOrFail($id);
        $absensi->update($validatedData);
        return redirect()->route('absensi.index')->with('success', 'Absensi berhasil diupdate!');
    }

    // Menghapus data absensi
    public function destroy($id)
    {
        $absensi = Absensi::findOrFail($id);
        $absensi->delete();
        return redirect()->route('absensi.index')->with('success', 'Absensi berhasil dihapus!');
    }

    // Menambahkan kolom id_absensi di tabel details (migrasi)
    public function up()
    {
        Schema::table('details', function (Blueprint $table) {
            $table->unsignedBigInteger('id_absensi')->after('id')->nullable(); // Menambahkan kolom id_absensi
        });
    }

    // Menghapus kolom id_absensi jika rollback
    public function down()
    {
        Schema::table('details', function (Blueprint $table) {
            $table->dropColumn('id_absensi'); // Menghapus kolom id_absensi
        });
    }
}
